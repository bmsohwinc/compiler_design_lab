# echo "You said: ${1}"
javac Main.java
java Main < "input.txt"